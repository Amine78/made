<footer>
	<nav class="nav">
		<ul>
			<li><img src="<?php bloginfo('template_directory'); ?>/img/web.png"alt=""></li>
			<li><img src="<?php bloginfo('template_directory'); ?>/img/cv.png"alt=""></li>
			<li><img src="<?php bloginfo('template_directory'); ?>/img/ce.png"alt=""></li>
			<li><img src="<?php bloginfo('template_directory'); ?>/img/jv.png"alt=""></li>
			<li><img src="<?php bloginfo('template_directory'); ?>/img/3d.png"alt=""></li>
			<li><img src="<?php bloginfo('template_directory'); ?>/img/facebook.png" alt="facebook"></li>
			<li><img src="<?php bloginfo('template_directory'); ?>/img/twitter.png" alt="facebook"></li>
		</ul>
	</nav>

</footer>
    
  </body>
</html>